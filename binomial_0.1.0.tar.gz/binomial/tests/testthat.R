library(testthat)
library(binomial)
source("../R/functions.R")

test_file("tests/testthat/tests.R")

